package com.java.jsf;

public enum Gender {
	MALE,FEMALE
}
